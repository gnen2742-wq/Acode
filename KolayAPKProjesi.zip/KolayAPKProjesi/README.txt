TELEFONDAN KOLAY APK YAPIMI

1- Bu klasörü ZIP'ten çıkar
2- GitHub'a yükle
3- Codemagic aç
4- Build APK de
5- APK otomatik oluşur

Paket adı:
com.kolayapk
