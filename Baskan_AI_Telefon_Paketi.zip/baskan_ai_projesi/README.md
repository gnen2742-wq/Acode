# Başkan AI

Türkçe ve İspanyolca destekli yapay zekâ sohbet uygulaması.

## Kurulum
1. Flutter kur.
2. `flutter pub get`
3. `flutter run`

## APK Oluşturma
`flutter build apk --release`

## API Anahtarı
`lib/services/openai_service.dart` içinde API anahtarını ekleyin.
