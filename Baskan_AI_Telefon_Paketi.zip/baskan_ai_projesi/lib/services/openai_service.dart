// OpenAI API entegrasyonu için başlangıç dosyası.
class OpenAIService {
  final String apiKey;
  OpenAIService(this.apiKey);
}
