import 'package:flutter/material.dart';
import 'screens/chat_screen.dart';

void main() {
  runApp(const BaskanAIApp());
}

class BaskanAIApp extends StatelessWidget {
  const BaskanAIApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Başkan AI',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const ChatScreen(),
    );
  }
}
