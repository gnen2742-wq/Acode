# Başkan AI – Telefonda Kullanım Rehberi

Bu paket, Başkan AI uygulamasının kaynak kodunu telefon üzerinden görüntülemek ve düzenlemek için hazırlanmıştır.

## Telefon Üzerinde Kullanım

### Seçenek 1: Acode ile Düzenleme
1. Android için Acode uygulamasını yükle.
2. Bu ZIP dosyasını indir ve çıkar.
3. Acode ile klasörü aç.
4. Kodları düzenle.

### Seçenek 2: Replit ile Çalıştırma
1. replit.com hesabı aç.
2. Bu dosyaları yeni bir Flutter projesine yükle.
3. Bulutta çalıştır.

## Gerçek APK Oluşturmak
APK üretmek için Flutter kurulu bir bilgisayar veya bulut derleme servisi gerekir.

## Önerilen Bulut Servisleri
- GitHub Codespaces
- Replit
- Codemagic

## OpenAI API Anahtarı
https://platform.openai.com/api-keys
